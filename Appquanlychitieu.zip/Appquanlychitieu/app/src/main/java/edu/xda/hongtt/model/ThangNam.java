package edu.xda.hongtt.model;

public class ThangNam {
    int id;
    String thangNam;

    public ThangNam(int id, String thangNam) {
        this.id = id;
        this.thangNam = thangNam;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getThangNam() {
        return thangNam;
    }

    public void setThangNam(String thangNam) {
        this.thangNam = thangNam;
    }
}
